const projectItem = () => {
  const inputValue = document.querySelector(".c-projects__add-list-item--input")
    .value;
  const selectValue = document.querySelector(
    ".c-projects__add-list-item--options"
  ).value;
  const selectStatus = selectValue.replace(/-/g, " ");
  projects[projectTarget].toDoList.push({
    title: inputValue,
    completed: false,
    status: selectStatus,
    statusId: selectValue
  });
};

const submitItem = () => {
  const addProjectForm = document.querySelector(
    ".c-projects__add-list-item--form"
  );
  addProjectForm.addEventListener("submit", e => {
    e.preventDefault();
    if (
      document
        .querySelector(".c-projects__add-list-item")
        .classList.contains("addItemActive")
    ) {
      closeAddListItem();
      projectItem();
      renderToDoList(projectTarget);
    }
    addProjectForm.reset();
  });
};

const newProjectColours = [...document.querySelectorAll(".c-colours__button")];

const errorCheck = () => {
  const activeError = document.querySelector(".c-add-project__error--colours");
  if (activeError.classList.contains("error")) {
    removeError();
  }
};

newProjectColours.forEach(newProjectColour => {
  newProjectColour.addEventListener("click", e => {
    removeActiveColour();
    e.target.classList.toggle("isActive");
    errorCheck();
  });
});

document.querySelector(".c-add-project__form").addEventListener("submit", e => {
  e.preventDefault();
  colourValidation();
  errorCheck();
});

const removeError = () => {
  const activeErrorMessage = document.querySelector(".error");
  activeErrorMessage.classList.remove("error");
};

const removeActiveColour = () => {
  const activeColours = [...document.querySelectorAll(".isActive")];
  activeColours.forEach(activeColour => {
    activeColour.classList.remove("isActive");
  });
};

const colourValidation = () => {
  const selectedColours = [...document.querySelectorAll(".c-colours__button")];
  const errorMessage = document.querySelector(".c-add-project__error--colours");
  selectedColours.forEach(selectedColour => {
    if (selectedColour.classList.contains("isActive")) {
      createObject();
      return true;
    } else {
      errorMessage.classList.add("error");
    }
  });
};
const resetForm = () => {
  document.querySelector(".c-add-project__form").reset();
  document
    .querySelector(".c-add-project__container")
    .classList.remove("c-add-project__container--active");
  removeActiveColour();
  errorCheck();
};

const projects = {
  GreenHouse: {
    dataId: "GreenHouse",
    title: "Green House",
    colour: "pink",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Vel cumque, ratione quidem tenetur nesciunt perspiciatis deserunt iusto obcaecati fugit soluta quisquam aperiam rem! Tempore, ut veniam vel temporibus maiores voluptas?",
    toDoList: [
      {
        title: "item 1",
        completed: false,
        status: "waiting",
        statusId: "waiting"
      },
      {
        title: "item 2",
        completed: false,
        status: "waiting",
        statusId: "waiting"
      }
    ]
  },
  CyberPunk: {
    dataId: "CyberPunk",
    title: "Cyber Punk",
    colour: "green",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Vel cumque, ratione quidem tenetur nesciunt perspiciatis deserunt iusto obcaecati fugit soluta quisquam aperiam rem! Tempore, ut veniam vel temporibus maiores voluptas?",
    toDoList: [
      {
        title: "item 3",
        completed: false,
        status: "waiting",
        statusId: "waiting"
      },
      {
        title: "item 4",
        completed: false,
        status: "waiting",
        statusId: "waiting"
      }
    ]
  }
};

const getTitleInitials = title => {
  const projectInitials = title.split(" ");
  const words = projectInitials
    .map(text => {
      const wordInitials = text.slice(0, 1);
      return wordInitials;
    })
    .join("");

  return words;
};

const projectIconList = document.querySelector(".c-projects__list");
const renderIcon = () => {
  const projectIcons = Object.values(projects)
    .map(item => {
      const words = getTitleInitials(item.title);
      return `<li class="c-projects__list--item project-Icon" data-id=${item.dataId}>
            <div class="c-projects--icon u-gradient-bg--${item.colour} project-Icon" data-id=${item.dataId}>
              <h1 class="c-projects--initals" data-id=${item.dataId}>${words}</h1>
            </div>
            <h2>${item.title}</h2>
        </li>`;
    })
    .join("");
  projectIconList.innerHTML = projectIcons;
  return projectIcons;
};
renderIcon();

const createObject = () => {
  const projectName = document.querySelector(".c-add-project__input--title")
    .value;
  const projectColour = document
    .querySelector(".isActive")
    .getAttribute("data-colour");
  const projectDescription = document.querySelector(
    ".c-add-project__input--description"
  ).value;
  const projectId = projectName.replace(/\s+/g, "");
  const newProject = () => ({
    dataId: projectId,
    title: projectName,
    colour: projectColour,
    description: projectDescription,
    toDoList: []
  });
  projects[projectId] = newProject();
  renderIcon();
  resetForm();
};

document.querySelector(".c-nav__button").addEventListener("click", () => {
  document
    .querySelector(".c-nav__list")
    .classList.toggle("c-nav__list--active");
});


const changeStatusDropDown = () => {
  const taskStatuses = [
    ...document.querySelectorAll(".c-status-change__select")
  ];
  taskStatuses.forEach(taskStatus => {
    taskStatus.innerHTML = `        

            <option class="c-status-change__select--item" value = "waiting">Waiting</option>
            <option class="c-status-change__select--item" value = "in-review">In Review</option>
            <option class="c-status-change__select--item" value = "in-progress">In Progress</option>
            <option class="c-status-change__select--item" value = "approved">Approved</option>`;
  });
  replaceStatus();
};

const replaceStatus = () => {
  console.log(projects[projectTarget]);
};

const projectToDoHeader = document.querySelector(
  ".c-projects-to-do__header--text-content"
);
const projectToDoList = document.querySelector(".c-projects-to-do__list");

const renderToDoList = projectName => {
  projectToDoHeader.innerHTML = `<h1 class="c-projects-to-do__header--title">${projects[projectName].title}</h1>
  <p class="c-projects-to-do__header--description">${projects[projectName].description}</p>`;
  const projectToDos = projects[projectName].toDoList
    .map(item => {
      return `
      <li class="c-list-item" data-id="${projects[projectName].dataId}">
        <label class="c-list-item__input">
          <input type="checkbox"/>
          <span class="c-list-item__input--custom">
            <svg xmlns="http://www.w3.org/2000/svg" class="c-list-item__svg--tick" width="27.788" height="19.548" viewBox="0 0 27.788 19.548">
              <path class="c-svg__check" d="M27.445,43.179a1.175,1.175,0,0,0-1.652,0L9.262,59.6,1.994,52.435a1.175,1.175,0,0,0-1.652,0,1.149,1.149,0,0,0,0,1.636l8.1,7.982a1.187,1.187,0,0,0,1.653,0L27.445,44.815a1.147,1.147,0,0,0,0-1.636C26.989,42.727,27.9,43.631,27.445,43.179Z" transform="translate(0 -42.84)"/>
            </svg>
          </span>
          <div class="c-list-item__text">              
            <p class="c-list-item__text--title">${item.title}</p>
            
          </div>     
        </label> 
          <select class="c-status-change__select ${item.statusId}"></select>
      </li>
      `;
    })
    .join("");
  projectToDoList.innerHTML = projectToDos;

  return projectToDos;
};

let projectTarget = "";
const createList = () => {
  const projectIcons = [...document.querySelectorAll(".c-projects--icon")];
  projectIcons.forEach(projectIcon => {
    projectIcon.addEventListener("click", e => {
      projectTarget = e.target.getAttribute("data-id");
      renderToDoList(projectTarget);
      submitItem();
      changeStatusDropDown();
    });
  });
};
createList();

const openProject = () => {
  const projectButtons = [...document.querySelectorAll(".c-projects--icon")];
  projectButtons.forEach(projectButton => {
    projectButton.addEventListener("click", e => {
      const projectIconBody = document.querySelector(
        ".c-container--project-body"
      );
      const projectToDo = document.querySelector(".c-container--project-list");
      projectIconBody.classList.add("activeProject");
      projectToDo.classList.add("activeList");
      e.target.classList.add("iconActive");
      isIconActive();
    });
  });
};

const closeProject = () => {
  const projectIconBody = document.querySelector(".c-container--project-body");
  const projectToDo = document.querySelector(".c-container--project-list");
  const activeProjects = [...document.querySelectorAll(".iconActive")];
  projectIconBody.classList.remove("activeProject");
  projectToDo.classList.remove("activeList");
  activeProjects.forEach(activeProject => {
    activeProject.classList.remove("iconActive");
  });
  openProject();
};
openProject();

document
  .querySelector(".c-projects-to-do__close--cross")
  .addEventListener("click", () => {
    closeProject();
  });

const isIconActive = () => {
  const activeProjects = [...document.querySelectorAll(".project-Icon")];
  activeProjects.forEach(activeProject => {
    activeProject.addEventListener("click", () => {
      if (activeProject.classList.contains("iconActive")) {
        closeProject();
        const activeAddListItem = document.querySelector(
          ".c-projects__add-list-item"
        );
        if (activeAddListItem.classList.contains("addItemActive")) {
          closeAddListItem();
        }
      }
    });
  });
};

document
  .querySelector(".c-add-project__button")
  .addEventListener("click", () => {
    document
      .querySelector(".c-add-project__container")
      .classList.toggle("c-add-project__container--active");
  });

document
  .querySelector(".c-add-project__header--svg")
  .addEventListener("click", () => {
    errorCheck();
    resetForm();
  });

document
  .querySelector(".c-projects-to-do__list-item--svg")
  .addEventListener("click", () => {
    document
      .querySelector(".c-projects__add-list-item")
      .classList.toggle("addItemActive");
  });
document
  .querySelector(".c-projects__add-list-item--header--svg")
  .addEventListener("click", () => {
    closeAddListItem();
  });

const closeAddListItem = () => {
  document.querySelector(".addItemActive").classList.remove("addItemActive");
};
