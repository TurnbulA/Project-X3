document.querySelector(".c-nav__button").addEventListener("click", () => {
  document
    .querySelector(".c-nav__list")
    .classList.toggle("c-nav__list--active");
});
